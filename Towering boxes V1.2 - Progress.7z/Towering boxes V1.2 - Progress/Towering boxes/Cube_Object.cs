﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Towering_boxes
{
    public class Cube_Object
    {
        readonly Random rand = new Random();

        private int Cube_height, Cube_width;
        private int Speed = 1;
        private int frmWidth, frmHeight, frmTHeight;
        //static Image BM = new Bitmap("Model.png");
        public PictureBox cube { get; }
        private int xSpeed, ySpeed;
        public int Width { get { return Cube_width; } }
        public int Height { get { return Cube_height; } }
        
        public Cube_Object(Form f)
        {
            frmWidth = f.ClientSize.Width;               //Sets Width of form
            frmHeight = f.ClientSize.Height;             //Sets Height of form
            frmTHeight = f.Height;                       //True Height of the form
            cube = new PictureBox();
            Cube_Sizing();
            cube.Width = Cube_width;
            cube.Height = Cube_height;
            cube.SizeMode = PictureBoxSizeMode.StretchImage;
            cube.BackColor = Color.Black;
            Center(true);
            f.Controls.Add(cube);
        }
        public Cube_Object(Form f, int Diff, int sped)
        {
            frmWidth = f.ClientSize.Width;               //Sets Width of form
            frmHeight = f.ClientSize.Height;             //Sets Height of form
            frmTHeight = f.Height;                       //True Height of the form
            xSpeed = Speed * f.ClientSize.Width/100 * (Diff*2);
            xSpeed += sped;
            ySpeed = xSpeed;
            if (rand.Next(2) == 1) xSpeed *= -1;
            cube = new PictureBox();
            Cube_Sizing();
            cube.Width = Cube_width;
            cube.Height = Cube_height;
            cube.SizeMode = PictureBoxSizeMode.StretchImage;
            cube.BackColor = Color.Black;
            Center(false);
            f.Controls.Add(cube);
        }

        public void Cube_Render(int height)                       //takes pillar height as measure
        {
            cube.Top = frmHeight - cube.Height*(height + 1) + 1;
        }
        public void Center(bool stack)
        {
            if (stack) cube.Top = frmHeight - (cube.Height * 1);  //centers Vertically
            cube.Left = (frmWidth / 2) - (cube.Width / 2);        //centers Horizontally
        }
        public void Move(bool Direction, int Side)        //True == Vertical, False == Horizontal
        {
            if (!Direction) cube.Left += xSpeed;
            else if (Direction)
            {
                if (Side == 1 & xSpeed < 0) xSpeed *= -1;
                else if (Side == 2 & xSpeed > 0) xSpeed *= -1;
                cube.Top += ySpeed;
                cube.Left += xSpeed;
            }
            //Left -> Right
            if (cube.Left + cube.Width > frmWidth)
                xSpeed *= -1;
            if (cube.Left <= 0)
                xSpeed *= -1;
            //Up -> Down
            if (cube.Top + cube.Height > frmHeight)
                ySpeed *= -1;
            if (cube.Top <= 0)
                ySpeed *= -1;
        }
        public void Cube_Sizing()
        {
            switch (frmTHeight)
            {
                case 200:
                    Cube_height = 16;
                    Cube_width = 16;
                    break;

                case 400:
                    Cube_height = 32;
                    Cube_width = 32;
                    break;

                case 600:
                    Cube_height = 48;
                    Cube_width = 48;
                    break;

                case 800:
                    Cube_height = 64;
                    Cube_width = 64;
                    break;

                case 1000:
                    Cube_height = 80;
                    Cube_width = 80;
                    break;
                default:
                    Cube_height = 32;
                    Cube_width = 32;
                    break;
            }
        }
    }
}
