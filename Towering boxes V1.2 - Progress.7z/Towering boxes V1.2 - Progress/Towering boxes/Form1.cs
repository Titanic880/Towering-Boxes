﻿using System;
using System.Windows.Forms;

namespace Towering_boxes
{
    public partial class Form1 : Form
    {
        private int Pillar_Height = 1;      //used to store the height that the stack has reached
        private int Difficulty = 2;
        private int Lvl = 1;
        private bool Started;
        private int stall;
        private int Direction = 0;
        private int GameMode = 0;
        Cube_Object[] cube_stack;
        public Form1()
        {
            InitializeComponent();

            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.UserPaint, true);
            cube_stack = new Cube_Object[12];
            Screen_Adjust();
        }
        private void cycle_tick(object sender, EventArgs e)
        {
            if (GameMode == 0) cube_stack[0].Move(false, 0);
            else if (GameMode == 1) cube_stack[0].Move(true, Direction);
            if (stall != 0) stall--;
        }
        private void UpStack()
        {
            cube_stack[0].Cube_Render(Pillar_Height);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (Started)
                if (stall == 0 & GameMode == 0)
                {
                    if (e.KeyCode == Keys.Space)
                    {
                        //lbl_Lvl.Text = (cube_stack[0].cube.Left - cube_stack[Pillar_Height].cube.Left) + " > " + (cube_stack[0].cube.Width / 2) + " , " +
                        //  Output Math  (cube_stack[0].cube.Left - cube_stack[Pillar_Height].cube.Left) + " < " + ((cube_stack[0].cube.Width / 2) * -1);
                        if (cube_stack[0].cube.Bounds.IntersectsWith(cube_stack[Pillar_Height].cube.Bounds))
                        {
                            cycle.Stop();
                            stall = 4;
                            if (cube_stack[0].cube.Left > cube_stack[1].cube.Left - cube_stack[1].cube.Width            //checks to see if player cube is within 1 cube size of the bottom
                              & cube_stack[0].cube.Right < cube_stack[1].cube.Right + cube_stack[1].cube.Width)
                                if (cube_stack[0].cube.Left - cube_stack[Pillar_Height].cube.Left < cube_stack[0].cube.Width / Difficulty
                                  & cube_stack[0].cube.Left - cube_stack[Pillar_Height].cube.Left > (cube_stack[0].cube.Width / Difficulty) * -1)
                                {
                                    Pillar_Height++;
                                    cube_stack[Pillar_Height] = new Cube_Object(this);
                                    cube_stack[Pillar_Height].cube.Top = cube_stack[0].cube.Top;
                                    cube_stack[Pillar_Height].cube.Left = cube_stack[0].cube.Left;
                                    cube_stack[0].cube.Top -= cube_stack[0].Height - 1;
                                    if (cube_stack[0].cube.Top - cube_stack[0].cube.Height < 0) score();
                                    cycle.Start();
                                    return;
                                }
                        }
                        Lost();
                    }
                }
                else if (stall == 0 & GameMode == 1) 
                {
                    if (e.KeyCode == Keys.A)
                        Direction = 1;
                    else if (e.KeyCode == Keys.D)
                        Direction = 2;
                }
        }
        private void score()
        {
            Lvl++;
            lbl_Lvl.Text = Lvl.ToString();
            for (int i = 0; i < cube_stack.Length; i++)
                if (cube_stack[i] != null)
                    cube_stack[i].cube.Dispose();
            cube_stack[0] = new Cube_Object(this, Difficulty, Lvl);
            cube_stack[Pillar_Height] = new Cube_Object(this);
            Pillar_Height = 1;
            UpStack();
        }

        #region Screen Render
        private void Form1_Resize(object sender, EventArgs e)
        {
            Screen_Adjust();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) //Changes Screen Size
        {
            Screen_Adjust();
        }
        private void Screen_Adjust()
        {
            switch (cb2.Text)
            {
                case "200":
                    this.Width = 200;
                    this.Height = 200;
                    break;
                case "400":
                    this.Width = 400;
                    this.Height = 400;
                    break;
                case "600":
                    this.Width = 600;
                    this.Height = 600;
                    break;
                case "800":
                    this.Width = 800;
                    this.Height = 800;
                    break;
                case "1000":
                    this.Width = 1000;
                    this.Height = 1000;
                    break;
                default:
                    this.Width = 400;
                    this.Height = 400;
                    break;
            }
            lbl_Lvl.Top = 20;
            lbl_Lvl.Left = 15;

            lbl1.Top = (this.ClientSize.Height / 2) - cb1.Height * 3;
            lbl1.Left = (this.ClientSize.Width / 2) - (lbl1.Width / 2);

            cb1.Top = (this.ClientSize.Height / 2) - ((cb1.Height * 2) + 4);
            cb1.Left = (this.ClientSize.Width / 2) - (cb1.Width / 2);

            cb2.Top = (this.ClientSize.Height / 2) - cb2.Height;
            cb2.Left = (this.ClientSize.Width / 2) - (cb2.Width / 2);

            cb3.Top = (this.ClientSize.Height / 2) - cb3.Height + cb2.Height + 4;
            cb3.Left = (this.ClientSize.Width / 2) - (cb3.Width / 2);
            btnStart.Top = (this.ClientSize.Height / 2) - btnStart.Height + cb2.Height + cb3.Height + 8;
            btnStart.Left = (this.ClientSize.Width / 2) - (btnStart.Width / 2);
        }

        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cb1.Text)
            {
                case "easy":
                    Difficulty = 1;
                    break;
                case "Normal":
                    Difficulty = 2;
                    break;
                case "Hard":
                    Difficulty = 3;
                    break;
                default:
                    Difficulty = 2;
                    break;
            }
        }
        private void cb3_SelectedIndexChanged(object sender, EventArgs e)   //Feature in Testing ;; completely new Game
        {/*
            switch (cb3.Text)
            {
                case "Standard":
                    GameMode = 0;
                    break;
                case "Tetris Style":
                    GameMode = 1;
                    break;
                default:
                    GameMode = 0;
                    break;
            }*/
        }
        #endregion Screen Render
        private void btnStart_Click(object sender, EventArgs e)
        {
            if (btnStart.Text == "Start!")
            {
                cube_stack[0] = new Cube_Object(this, Difficulty, Lvl);
                cube_stack[Pillar_Height] = new Cube_Object(this);
                UpStack();
                stall = 0;
                Direction = 0;
                lbl1.Visible = false;
                lbl1.Enabled = false;
                btnStart.Visible = false;
                btnStart.Enabled = false;
                cb1.Visible = false;
                cb1.Enabled = false;
                cb2.Visible = false;
                cb2.Enabled = false;
                cb3.Visible = false;
                cb3.Enabled = false;
                Started = true;
                lbl_Lvl.Visible = true;
                btnStart.Text = "Restart?";
                cycle.Start();
            }
            else if(btnStart.Text == "Restart?")
            {
                Started = false;
                lbl_Lvl.Visible = false;
                lbl1.Visible = true;
                cb1.Visible = true;
                cb2.Visible = true;
                lbl1.Enabled = true;
                cb1.Enabled = true;
                cb2.Enabled = true;
                for (int i = 0; i < cube_stack.Length; i++)
                    if (cube_stack[i] != null)
                        cube_stack[i].cube.Dispose();
                Pillar_Height = 1;
                btnStart.Text = "Start!";
            }
        }
        void Lost()
        {
            btnStart.Visible = true;
            btnStart.Enabled = true;
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            Direction = 0;
        }
    }
}
