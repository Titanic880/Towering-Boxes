﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Towering_boxes
{
    public class Cube_Object
    {
        readonly Random rand = new Random();

        private const int Cube_height = 32, Cube_width = 32;
        private int Speed = 1;
        private int frmWidth, frmHeight;
        //static Image BM = new Bitmap("Model.png");
        public PictureBox cube { get; }
        private int xSpeed;
        public int Width { get { return Cube_width; } }
        public int Height { get { return Cube_height; } }
        
        public Cube_Object(Form f)
        {
            frmWidth = f.ClientSize.Width;               //Sets Width of form
            frmHeight = f.ClientSize.Height;             //Sets Height of form
            cube = new PictureBox();
            cube.Width = 32;
            cube.Height = 32;
            cube.SizeMode = PictureBoxSizeMode.StretchImage;
            cube.BackColor = Color.Black;
            Center(true , 1);
            f.Controls.Add(cube);
        }
        public Cube_Object(Form f, int Diff)
        {
            frmWidth = f.ClientSize.Width;               //Sets Width of form
            frmHeight = f.ClientSize.Height;             //Sets Height of form
            xSpeed = Speed * f.ClientSize.Width/100;
            xSpeed *= Diff;
            if (rand.Next(2) == 1) xSpeed *= -1;
            cube = new PictureBox();
            cube.Width = 32;
            cube.Height = 32;
            cube.SizeMode = PictureBoxSizeMode.StretchImage;
            cube.BackColor = Color.Black;
            Center(false, 1);
            f.Controls.Add(cube);
        }

        public void Cube_Render(int height) //takes pillar height as measure
        {
            cube.Top = frmHeight - cube.Height*(height + 1) + 1;
        }
        public void Center(bool stack, int size)
        {
            if (stack) cube.Top = frmHeight - (cube.Height * size);  //centers Vertically
            cube.Left = (frmWidth / 2) - (cube.Width / 2);   //centers Horizontally
        }
        public void Move()
        {
            cube.Left += xSpeed;

            //Left -> Right
            if (cube.Left + cube.Width > frmWidth)
                xSpeed *= -1;
            if (cube.Left <= 0)
                xSpeed *= -1;
        }
    }
}
