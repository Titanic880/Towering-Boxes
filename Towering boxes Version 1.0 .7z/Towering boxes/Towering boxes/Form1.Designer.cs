﻿namespace Towering_boxes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cycle = new System.Windows.Forms.Timer(this.components);
            this.cb2 = new System.Windows.Forms.ComboBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.cb1 = new System.Windows.Forms.ComboBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl_Lvl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cycle
            // 
            this.cycle.Interval = 35;
            this.cycle.Tick += new System.EventHandler(this.cycle_tick);
            // 
            // cb2
            // 
            this.cb2.FormattingEnabled = true;
            this.cb2.Items.AddRange(new object[] {
            "200",
            "400",
            "600",
            "800",
            "1000"});
            this.cb2.Location = new System.Drawing.Point(318, 273);
            this.cb2.Name = "cb2";
            this.cb2.Size = new System.Drawing.Size(121, 21);
            this.cb2.TabIndex = 1;
            this.cb2.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(318, 300);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(121, 23);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start!";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // cb1
            // 
            this.cb1.FormattingEnabled = true;
            this.cb1.Items.AddRange(new object[] {
            "Easy",
            "Normal",
            "Hard"});
            this.cb1.Location = new System.Drawing.Point(318, 246);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(121, 21);
            this.cb1.TabIndex = 3;
            this.cb1.SelectedIndexChanged += new System.EventHandler(this.cb1_SelectedIndexChanged);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(282, 220);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(191, 13);
            this.lbl1.TabIndex = 4;
            this.lbl1.Text = "Select Difficulty and Screen Resolution";
            // 
            // lbl_Lvl
            // 
            this.lbl_Lvl.AutoSize = true;
            this.lbl_Lvl.Location = new System.Drawing.Point(12, 25);
            this.lbl_Lvl.Name = "lbl_Lvl";
            this.lbl_Lvl.Size = new System.Drawing.Size(35, 13);
            this.lbl_Lvl.TabIndex = 5;
            this.lbl_Lvl.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 761);
            this.Controls.Add(this.lbl_Lvl);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.cb2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Dropper";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer cycle;
        private System.Windows.Forms.ComboBox cb2;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ComboBox cb1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl_Lvl;
    }
}

