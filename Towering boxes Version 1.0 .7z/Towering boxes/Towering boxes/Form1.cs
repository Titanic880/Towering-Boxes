﻿using System;
using System.Windows.Forms;

namespace Towering_boxes
{
    public partial class Form1 : Form
    {
        //Cube cube;
        private int Pillar_Height = 1;      //used to store the height that the stack has reached
        private int Difficulty = 2;
        Cube_Object cube;
        Cube_Object[] start;
        public Form1()
        {
            InitializeComponent();

            SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.UserPaint, true);
            start = new Cube_Object[20];
            Screen_Adjust();
        }
        private void cycle_tick(object sender, EventArgs e)
        {
            cube.Move();
            lbl_Lvl.Text = cube.cube.Bottom + ", " + start[Pillar_Height].cube.Top; 
        }
        public void UpStack()
        {
            cube.Cube_Render(Pillar_Height);
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                if (cube.cube.Bounds.IntersectsWith(start[Pillar_Height].cube.Bounds))
                {
                    cycle.Stop();
                    if (cube.cube.Left - start[Pillar_Height].cube.Left > 16)
                    {
                        Lost();
                        return;
                    }
                    else
                    {
                        Pillar_Height++;
                        start[Pillar_Height] = new Cube_Object(this);
                        start[Pillar_Height].cube.Top = cube.cube.Top;
                        start[Pillar_Height].cube.Left = cube.cube.Left;
                        cube.cube.Top -= cube.Height-1;
                        cycle.Start();
                    }
                }
                else Lost();
            }
        }
        #region Screen Render
        private void Form1_Resize(object sender, EventArgs e)
        {
            Screen_Adjust();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) //Changes Screen Size
        {
            Screen_Adjust();
        }
        private void Screen_Adjust()
        {
            switch (cb2.Text)
            {
                case "200":
                    this.Width = 200;
                    this.Height = 200;
                    break;
                case "400":
                    this.Width = 400;
                    this.Height = 400;
                    break;
                case "600":
                    this.Width = 600;
                    this.Height = 600;
                    break;
                case "800":
                    this.Width = 800;
                    this.Height = 800;
                    break;
                case "1000":
                    this.Width = 1000;
                    this.Height = 1000;
                    break;
                default:
                    this.Width = 400;
                    this.Height = 400;
                    break;
            }
            lbl_Lvl.Top = 20;
            lbl_Lvl.Left = 15;

            lbl1.Top = (this.ClientSize.Height / 2) - cb1.Height * 3;
            lbl1.Left = (this.ClientSize.Width / 2) - (lbl1.Width / 2);

            cb1.Top = (this.ClientSize.Height / 2) - ((cb1.Height * 2) + 4);
            cb1.Left = (this.ClientSize.Width / 2) - (cb1.Width / 2);

            cb2.Top = (this.ClientSize.Height / 2) - cb2.Height;
            cb2.Left = (this.ClientSize.Width / 2) - (cb2.Width / 2);

            btnStart.Top = (this.ClientSize.Height / 2) - btnStart.Height + cb2.Height + 4;
            btnStart.Left = (this.ClientSize.Width / 2) - (btnStart.Width / 2);
        }

        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cb1.Text)
            {
                case "easy":
                    Difficulty = 1;
                    break;
                case "Normal":
                    Difficulty = 2;
                    break;
                case "Hard":
                    Difficulty = 3;
                    break;
                default:
                    Difficulty = 2;
                    break;
            }
        }
        #endregion Screen Render
        private void btnStart_Click(object sender, EventArgs e)
        {
            cube = new Cube_Object(this, Difficulty);
            start[Pillar_Height] = new Cube_Object(this);
            UpStack();
            lbl1.Visible = false;
            cb1.Visible = false;
            cb2.Visible = false;
            btnStart.Visible = false;
            lbl1.Enabled = false;
            cb1.Enabled = false;
            cb2.Enabled = false;
            btnStart.Enabled = false;
            this.Refresh();
            cycle.Start();
        }
        void Lost()
        {
            lbl1.Visible = true;
            cb1.Visible = true;
            cb2.Visible = true;
            btnStart.Visible = true;
            lbl1.Enabled = true;
            cb1.Enabled = true;
            cb2.Enabled = true;
            btnStart.Enabled = true;
            cube.cube.Dispose();
            for(int i = 1; i < start.Length; i++)
                if(start[i] != null)
                    start[i].cube.Dispose();
            
            Pillar_Height = 1;
        }
    }
}
